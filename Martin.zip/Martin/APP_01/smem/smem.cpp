// Archivo DLL principal.
int main0(int pars);
# define _SECURE_SCL 0
// Archivo DLL principal.
#include <math.h>
#include <windows.h>
#include <fstream>
#include <stdio.h>
#include <cstdlib>
#include <iostream>


using namespace std;

LPVOID lpvMem = NULL;      // pointer to shared memory
HANDLE hMapObject = NULL;  // handle to file mapping
HANDLE hMapObjectx = NULL;  // handle to file mapping

__declspec(dllexport) int __cdecl execute() ;
__declspec(dllexport) void __cdecl load() ;
int MEMPILES =16;       //indice de pila entero //4 vacios //4 cur // 4 cur sent
int MEMFLOAT= 1024*4*24 ;    //define una memoria con capacidad de 1000 flotantes
int MEMINT=  1024*4*24  ;     //define una memoria con capacidad de 1000 enteros



int TOTMEM;
int posPILE;
int posPILEF;
//calcula las variables de offset

int OFFSET_MEMFLOAT;
int OFFSET_MEMINT;
int OFFSET_MEMMODDATA;

#include <fstream>


void init(){
	//RESERVAMOS UNOS BYTES INTERNOS JEJEJ
OFFSET_MEMFLOAT= 16;
OFFSET_MEMINT= 16;//tienen la misma direccion
OFFSET_MEMMODDATA=OFFSET_MEMFLOAT+MEMFLOAT;
TOTMEM= OFFSET_MEMMODDATA+MEMFLOAT+1024;

}


float af;
float *bf;
int a;
int *b;
int *c;
int *p;
int p0;




 void SetFloat(float ax,int pos) 
{
p0=(int)int (int(lpvMem)+int(OFFSET_MEMFLOAT)+int(pos*4));
c=(int *) p0;
bf =(float *) c;
    *bf=ax;    
} 
  


void SetRaw(unsigned char a,int pos) 
{
   
unsigned char  *b;
int p0;
p0=(int)int(int(lpvMem)+int(OFFSET_MEMFLOAT)+int(pos));
b=(unsigned char *)p0;
*b=a;     
} 


 unsigned char GetRaw(int pos) 
{ 
unsigned char a;
unsigned char *b;
int *c;
int p0;
p0=(int)int(int(lpvMem)+int(OFFSET_MEMFLOAT)+int(pos));
c=(int *) p0;
b =(unsigned char *) c;
a=  *b;
return a;
}


 float  GetFloat(int pos) 
{ 
p0=(int)int(int(lpvMem)+int(OFFSET_MEMFLOAT)+int(pos*4));
c=(int *) p0;
bf =(float *) c;
af=  *bf;
return af;
}




int  GetInt(int pos) 
{ 
p0=(int)int(int(lpvMem)+int(OFFSET_MEMINT)+int(pos*4));
c=(int *) p0;
b =(int *) c;
a=  *b;
return a;
}


void  SetInt(int a,int pos) 
{
p0=(int)int(int(lpvMem)+int(OFFSET_MEMINT)+int(pos*4));
c=(int *) p0;
b =(int *) c;
    *b=a;    
} 






// funciones de inicializacion de memoria y acceso a memoria compartida


//----------Definiciones de Control de errores----------------
FARPROC lpfnGetADD ;
FARPROC lpfnGetADD2 ;
FARPROC lpfnGetADD3 ;
typedef  void (__stdcall * pICDLLFUNC00)();//(char *); 
   pICDLLFUNC00 TRACE; 
typedef  void (__stdcall * pICDLLFUNC01)(EXCEPTION_POINTERS* pExp, DWORD dwExpCode);//(char *); 
   pICDLLFUNC01 TRACE2; 
typedef  void (__stdcall * pICDLLFUNC02)(char ID[]);//(char *); 
   pICDLLFUNC02 MYID; 

bool fInit;  
BOOL fIgnore; 

__declspec(dllexport) void __cdecl load() 
{ 
init();
    printf ("\n Programa APP_01");
     hMapObject = CreateFileMapping( 
                    INVALID_HANDLE_VALUE ,  // Permite crear FileMapping
                    NULL,                   // Sin Atributos de seguridad
                    PAGE_READWRITE,         // Todos pueden leer y escribir
                    0,                      // Tamano: 64-bits Superiores
                    TOTMEM,                 // Tamano: 64-bits Inferiores
                    TEXT("PROCESS_INTEROP_MEM")); // Nombre del archivo virtual
     if (hMapObject == NULL) 
        printf ("\n Falla de inicializacion...Sin memoria");
     fInit = (GetLastError() != ERROR_ALREADY_EXISTS);
     if (fInit==true){  
   
         printf ("\n Este programa se iniciado como MASTER de la memoria compartida");
   
     }
     else{
        printf ("\n Este programa se iniciado como cliente de la memoria compartida");
        }
     lpvMem = MapViewOfFile(hMapObject,// Obtencion del puntero a la memoria compartida
                            FILE_MAP_ALL_ACCESS, // Acceso sin restriciones
                            0,              // leer todo
                            0,              // 
                            0);             // 
     if (lpvMem == NULL) 
         printf ("\n No se creo apuntador");            
     printf ("\n Listo para acceder a la memoria ",TOTMEM);

// INICIA LA MEMORIA COMPARTIDA
p0=(int)lpvMem+4;
c=(int *) p0;
b =(int *) c;
*b=0;//posPILE; 
p0=(int)lpvMem+8;
c=(int *) p0;
b =(int *) c;
*b=0;//posPILEF; 


//carga el debugger

HINSTANCE hGetProcIDDLL2 = LoadLibrary(L"kernel.dll"); 
if (!hGetProcIDDLL2  ){
	cout<<"No se encontro el dll solicitado: kernel.dll";
}
lpfnGetADD = GetProcAddress(HMODULE (hGetProcIDDLL2),"?CALLSTACK@@YAHXZ");    
TRACE = pICDLLFUNC00(lpfnGetADD) ;
lpfnGetADD2 = GetProcAddress(HMODULE (hGetProcIDDLL2),"?ExpFilter@@YGJPAU_EXCEPTION_POINTERS@@K@Z");    
TRACE2 = pICDLLFUNC01(lpfnGetADD2) ;
lpfnGetADD3 = GetProcAddress(HMODULE (hGetProcIDDLL2),"?NAME@@YAHQAD@Z");    
MYID = pICDLLFUNC02(lpfnGetADD3) ;
MYID("LOADED ON SITE DEBUGGER IN APP_0 ");
cout<<"\n******************************\nCargando On Site Debugger ...";


}





//----------Fin Funciones Virtuales (Permiten debugger)-------
#pragma unmanaged

//----------**************STACK TRACE**************-----------
   LONG WINAPI ExpFilterO(EXCEPTION_POINTERS* pExp, DWORD dwExpCode)
{
	cout<<"Aplicacion Interrumpida - On Site Debugger en Diagnostico";
	TRACE2(pExp, dwExpCode);
	return EXCEPTION_EXECUTE_HANDLER;
}
//-------**************Entrada de Main**************----------
__declspec(dllexport) int __cdecl execute(int pars) 

{
__try
{
	
///////////////////////////////////////////////FIN Funiones de Genericas De Control //////////////////////
	int su;
	su=main0(pars);          ////cambiar por la funcion main local
	return su;
///////////////////////////////////////////////Funiones de control de errores//////////////////////
}
__except(ExpFilterO(GetExceptionInformation(), GetExceptionCode()))
{
	
	system("pause");
	return -1;
}
}


//----------FIN DE FUNCIONES DE DEBUGGER----------------------





//funcion de entrada de ejecucion  
 int main0(int pars) 
{ 
//ejemplo de ejecucion...genera la raiz cuadrada
int i=0;
for (i=0;i<5000;i++){
SetFloat(sqrt((float)i),i);
}
if (pars==1){
int p=5/((int)sqrt(1.0f)-1);
}
return 1;

}
