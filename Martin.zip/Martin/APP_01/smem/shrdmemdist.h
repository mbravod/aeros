#ifndef _shrdmemdist_H_
#define _shrdmemdist_H_

#include <iostream>


#endif